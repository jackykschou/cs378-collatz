var searchData=
[
  ['meta_5fcache',['meta_cache',['../Collatz_8c_09_09.html#aea222bff6a97ec390d6ad12d72a88977',1,'meta_cache():&#160;Collatz.c++'],['../SphereCollatz_8c_09_09.html#aea222bff6a97ec390d6ad12d72a88977',1,'meta_cache():&#160;SphereCollatz.c++']]]
];
