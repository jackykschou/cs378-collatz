var searchData=
[
  ['lazy_5fcache',['lazy_cache',['../Collatz_8c_09_09.html#acdcf8de024832639579ede1080f324e5',1,'lazy_cache():&#160;Collatz.c++'],['../SphereCollatz_8c_09_09.html#acdcf8de024832639579ede1080f324e5',1,'lazy_cache():&#160;SphereCollatz.c++']]]
];
