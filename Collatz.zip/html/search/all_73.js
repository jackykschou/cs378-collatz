var searchData=
[
  ['spherecollatz_2ec_2b_2b',['SphereCollatz.c++',['../SphereCollatz_8c_09_09.html',1,'']]]
];
