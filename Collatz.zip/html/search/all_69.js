var searchData=
[
  ['interval',['INTERVAL',['../Collatz_8c_09_09.html#ab39fec97d85960796efedec442f38004',1,'INTERVAL():&#160;Collatz.c++'],['../SphereCollatz_8c_09_09.html#ab39fec97d85960796efedec442f38004',1,'INTERVAL():&#160;SphereCollatz.c++']]]
];
